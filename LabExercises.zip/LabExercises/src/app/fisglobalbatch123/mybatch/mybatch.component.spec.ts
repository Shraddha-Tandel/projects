import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MybatchComponent } from './mybatch.component';

describe('MybatchComponent', () => {
  let component: MybatchComponent;
  let fixture: ComponentFixture<MybatchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MybatchComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MybatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
