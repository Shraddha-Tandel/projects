import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mybatch',
  templateUrl: './mybatch.component.html',
  styleUrls: ['./mybatch.component.css']
})
export class MybatchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
