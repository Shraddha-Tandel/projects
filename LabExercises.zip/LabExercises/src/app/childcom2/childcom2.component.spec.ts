import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Childcom2Component } from './childcom2.component';

describe('Childcom2Component', () => {
  let component: Childcom2Component;
  let fixture: ComponentFixture<Childcom2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Childcom2Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Childcom2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
