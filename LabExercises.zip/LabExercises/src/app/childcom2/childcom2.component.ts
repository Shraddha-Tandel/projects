import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-childcom2',
  templateUrl: './childcom2.component.html',
  styleUrls: ['./childcom2.component.css']
})
export class Childcom2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
/*
A common pattern in Angular is sharing data between a parent component and one or more child components. 
Implement this pattern with the @Input() and @Output() decorators.

@Input() lets a parent component update data in the child component. 
Conversely, @Output() lets the child send data to a parent component.
*/
//@Input-get or inject the parent(root) component data here!
@Input("productname")
 public pname:string | undefined;//4
@Input("productprice") 
price1:number | undefined;//4

/*
 ngOnChanges is not called every time a 
 component property changes internally.  It gets called when the databinding from the 
  parent component "pushes a new value" into   the child component.
 */
/*
ngOnChanges() is called every time inputs are updated by change detection.
 ngAfterViewInit() is called after the view 
is initially rendered. This is why @ViewChild() depends on it.
 You can't access view members before they are rendered.
*/
//Called before ngOnInit()
/*
 if your component has no inputs or you use it without 
 providing any inputs, 
 the framework will not call ngOnChanges().
*/
ngOnChanges()
{
  console.log("Childcom2--ngOnChanges!!!!!");
  console.log("Inside Child Component:: "+this.pname + " "+this.price1);
}

}
