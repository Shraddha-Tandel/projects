import { Component, OnInit } from '@angular/core';

/*
templateUrl:: This is a property that expects an "external HTML file" that will serve as the
template for this component.

If you change it to ""template""""", you can specify inline HTML it's not possible to use 
both style and styleUrls together
styles property should be used when the number of style properties is less than ten or so.

If you have to define a lot of CSS styles, then it is always better to put them in separate files and 
use the styleUrls property
*/

@Component({
  selector: 'app-nocssnohtmlonlyts',
//  templateUrl: './nocssnohtmlonlyts.component.html',
 // styleUrls: ['./nocssnohtmlonlyts.component.css']
 template: 
 `
 <p>This is my inline template HTML!</p>
 <h1>This is my inline heading</h1>
 Name:: {{myname}}
 <p>
 Loop Through JSON
 </p>
 <!--The KeyValue Pipe converts given Object or Map into
 an array of key-value pairs. We can use this
 with the ngFor to loop through the object keys. -->
 <div *ngFor='let item of jsonObj | keyvalue'>
 Key: {{item.key}}
 JSON FORMAT:: {{item|json}}
 <div *ngFor='let obj of item.value'>
 {{ obj.Name }}
 {{ obj.Dept }}
 </div>
 </div>
 `,
  styles:
  [`
  p { font-weight: bold;color:red; }
  h1 { color: gray; }
   `]
})
export class NocssnohtmlonlytsComponent implements OnInit {
  myname="Thananya";
  jsonObj = {
  '1001' :
  [ {"Name" : "Thananya" , "Dept" : "IT" }],
  '2001' :
  [ {"Name" : "Raja" , "Dept" : "HR" }],
  '3001' :
  [ {"Name" : "Devi" , "Dept" : "IT" }],
  '4001' :
  [ {"Name" : "Lakshmi" , "Dept" : "IT" }],
  '5001' :
  [ {"Name" : "Sara" , "Dept" : "Networking" }]
  }


  constructor() { }

  ngOnInit(): void {
  }

}
