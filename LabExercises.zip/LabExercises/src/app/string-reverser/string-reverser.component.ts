import { Component } from '@angular/core';

@Component({
  selector: 'app-string-reverser',
  templateUrl: './string-reverser.component.html',
  styleUrls: ['./string-reverser.component.css']
})
export class StringReverserComponent {
  inputString: string = ''; // To store the input string
  reversedString: string = ''; // To store the reversed string

  // Method to reverse the string
  reverseString(): void {
    this.reversedString = this.inputString.split('').reverse().join('');
  }
}
