import { FisPuneDirective } from './fispune.directive';
import { ElementRef } from '@angular/core';

describe('FisPuneDirective', () => {
  it('should create an instance', () => {
    const mockElementRef: ElementRef = new ElementRef(document.createElement('div')); 
    const directive = new FisPuneDirective(mockElementRef); 
    expect(directive).toBeTruthy();
  });
});
