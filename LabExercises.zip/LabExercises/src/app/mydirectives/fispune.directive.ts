import { Directive, ElementRef } from '@angular/core';
//Decorator that marks a class as an Angular directive

@Directive({
  selector: '[Fischennaibatch]'
})


export class FisPuneDirective {


  constructor(elementobj:ElementRef)
  {
  console.log(elementobj);

  elementobj.nativeElement.style.color="darkviolet";
  elementobj.nativeElement.style.backgroundColor="yellow";
  elementobj.nativeElement.innerText+=" -- rendered by UserDefinedDirective-FISGLOBAL";
  }



}
