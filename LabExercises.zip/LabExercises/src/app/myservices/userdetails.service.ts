import { Injectable } from '@angular/core';
//@Injectable() decorator makes the SERVICE class injectable into
//any application components.

@Injectable({
  providedIn: 'root'
})
/*
providedIn property registers your Service at the root level (app module).
When the Service is provided at the root level,Angular creates a ""singleton"" instance of the service class
and injects the same instance into any class that uses this service class. */
/*
When the service class is added in the providers property of the root module, all the directives and components will
have access to the same instance of the service.
*/

/*
With providedIn: 'any', all eagerly loaded modules share a  singleton instance;
however, lazy loaded modules each get their own unique instance*/
/*
Eager Loading: used to load core modules and feature modules that are required to start the application. ...
Lazy Loading: all other could be lazily loaded ""on demand""" after the application started.

Eager loading is the default loading strategy for components in Angular. It loads all the components 
registered in the app module for the first time. Once all the components are loaded, they will be rendered on the page.
*/
/*
What is dependecy Injection and why do we use it ?
Dependency Injection (DI) is a mechanism where the required
resources will be injected into the code automatically.
Angular comes with a in-built dependency injection subsystem.
--DI allows developers to reuse the code across application.
--DI makes the application development and testing much easier.
--DI makes the code loosely coupled.
--DI allows the developer to ask for the dependencies from Angular. There is no need for the
developer to explicitly create/instantiate them.
--Angular dependency injection aims to decouple the implementation of services from components. 
What is Service and why do we use it?
A service in Angular is a class which contains some functionality that can be reused across the application. 
A service is a
singleton object. Angular services are a mechanism of abstracting shared code and functionality throughout the
application.
Angular Services come as objects which are wired together using dependency injection.
Angular provides a few inbuilt services. We can also create custom services.

Why Services?
--Services can be used to share the code across components of an application.
--Services can be used to make HTTP requests.
*/


export class UserdetailsService {
  constructor() { }
  Hobbies = [
    'Shopping',
    'Reading',
    'Internet',
    'Cooking'
    ];
    Display3()
    {
    return 'Angular Service method Loaded!';
    }
    getTime12()
    {
    return new Date();
    }
    getStudents(): any[] 
    {
      return [
      {
      ID: 'std101', FirstName: 'Preety', LastName: 'Tiwary',
      Branch: 'CSE', DOB: '29/02/1988', Gender: 'Female'
      },
      {
      ID: 'std102', FirstName: 'Anurag', LastName: 'Mohanty',
      Branch: 'ETC', DOB: '23/05/1989', Gender: 'Male'
      },
      {
      ID: 'std103', FirstName: 'Priyanka', LastName: 'Dewangan',
      Branch: 'CSE', DOB: '24/07/1992', Gender: 'Female'
      },
      {
      ID: 'std104', FirstName: 'Hina', LastName: 'Sharma',
      Branch: 'ETC', DOB: '19/08/1990', Gender: 'Female'
      },
      {
      ID: 'std105', FirstName: 'Sambit', LastName: 'Satapathy',
      Branch: 'CSE', DOB: '12/94/1991', Gender: 'Male'
      }
      ];
    }

}
