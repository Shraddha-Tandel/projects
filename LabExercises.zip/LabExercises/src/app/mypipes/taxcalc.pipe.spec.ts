import { TaxcalcPipe } from './taxcalc.pipe';

describe('TaxcalcPipe', () => {
  it('create an instance', () => {
    const pipe = new TaxcalcPipe();
    expect(pipe).toBeTruthy();
  });
});
