import { Pipe, PipeTransform } from '@angular/core';
//@Pipe decorator allows you to define the pipe name

@Pipe({
  name: 'fistaxcalc'
})
//typescript class
/*
What is PipeTransform?
An interface that is implemented by pipes in order to perform a transformation.
Angular invokes the ""transform method""" with the value of a binding as the first argument
and any parameters as the second argument in list form.
*/

export class TaxcalcPipe implements PipeTransform {
//unknown is a datatype!
  /*transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }*/
  transform(salaryvalue: any, ...args:any): any
{
return salaryvalue*0.1;//10%
}

}
