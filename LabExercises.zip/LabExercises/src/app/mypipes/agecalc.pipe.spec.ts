import { AgecalcPipe } from './agecalc.pipe';

describe('AgecalcPipe', () => {
  it('create an instance', () => {
    const pipe = new AgecalcPipe();
    expect(pipe).toBeTruthy();
  });
});
