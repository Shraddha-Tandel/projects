import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fisgenderidentity'
})
export class IdentityPipe implements PipeTransform {

  /*transform(value: unknown, ...args: unknown[]): unknown {
return null;
}*/
transform(value: string, gender: string): string
{
if (gender.toLowerCase() == "male")
return "Mr." + value; //Mr.empname
else
return "Miss." + value; //Miss.empname
}
}
