import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fisagecalc'
})
export class AgecalcPipe implements PipeTransform {

   /*transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }*/
  transform(dobvalue: string): string
{
let currentYear: any = new Date().getFullYear();
let empBirthYear: any = new Date(dobvalue).getFullYear();
let empAge:any = currentYear - empBirthYear;
return empAge//age output
}
}
