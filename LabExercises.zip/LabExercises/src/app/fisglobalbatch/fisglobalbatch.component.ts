import { Component, OnInit } from '@angular/core';

@Component({
  //By default all component selector starts with 'app

  selector: 'fisglobaltraining',
  templateUrl: './fisglobalbatch.component.html',
  styleUrls: ['./fisglobalbatch.component.css']
})

//interface OnInit
//Define an ngOnInit() method 

export class FisglobalbatchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  salary=10000;

}
