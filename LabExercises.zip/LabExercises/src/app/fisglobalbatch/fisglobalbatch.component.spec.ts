import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FisglobalbatchComponent } from './fisglobalbatch.component';

describe('FisglobalbatchComponent', () => {
  let component: FisglobalbatchComponent;
  let fixture: ComponentFixture<FisglobalbatchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FisglobalbatchComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FisglobalbatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
