import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-receiver',
  templateUrl: './receiver.component.html',
  styleUrls: ['./receiver.component.css']
})
export class ReceiverComponent {
  @Input() parentMessage: string = '';
  @Output() messageFromReceiver: EventEmitter<string> = new EventEmitter<string>();
  messageToParent: string = '';

  sendMessageToParent() {
    this.messageFromReceiver.emit(this.messageToParent);
    this.messageToParent = ''; // Clear input after sending
  }
}
