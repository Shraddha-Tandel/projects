import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FISValidation } from '../TypeScriptClasses/Age.Validator';

@Component({
  selector: 'app-reactiveforms',
  templateUrl: './reactiveforms.component.html',
  styleUrls: ['./reactiveforms.component.css']
})
/*
template driven form::
--most of the logic is driven from the html template

reactive forms:
--logic resides mainly in the component or .ts file!
--Reactive forms are forms where we define the structure
of the
form in the component class. i.e we create the form model with
Form Groups, Form Controls, and Form Arrays.
--We also define the validation rules in the component class.
--Then, we bind it to the HTML form in the template.
***Template Driven Forms are based only on .html template
directives,
while Reactive forms are defined programmatically
at the level of the component class (.ts).
*/

/*
FormGroups which typically represents a single form.
A FormGroup is typically made of many FormControls.
A FormControl usually represents a single input in a form.
*/

export class ReactiveformsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
//FORM STRUCTURE
formobj = new FormGroup({
  name: new FormControl('', [Validators.required,  Validators.minLength(3),Validators.pattern('[a-z]+')]),
  email: new FormControl('', [Validators.required,  Validators.email]),
  contact1:new FormControl("",[Validators.required,  Validators.pattern('[0-9]*'),Validators.minLength(10)]),
  body: new FormControl('', Validators.required),

   //Custom Validator Control
   age: new FormControl('',[Validators.required,FISValidation.FIS_ageRangeValidator])//classname.validationfunctionname


});

get f()//method referred in .html
{
return this.formobj.controls;
}

fissubmit()
{
console.log(this.formobj.value);//DISPLAY ALL FORM VALUES!
}

}
