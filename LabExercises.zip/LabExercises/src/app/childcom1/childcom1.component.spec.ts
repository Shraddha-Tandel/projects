import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Childcom1Component } from './childcom1.component';

describe('Childcom1Component', () => {
  let component: Childcom1Component;
  let fixture: ComponentFixture<Childcom1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Childcom1Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Childcom1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
