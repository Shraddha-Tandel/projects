import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-childcom1',
  templateUrl: './childcom1.component.html',
  styleUrls: ['./childcom1.component.css']
})
export class Childcom1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  childmsg11:string="Hii!!!Iam Child Component Variable,Injected in Root Component";

}
