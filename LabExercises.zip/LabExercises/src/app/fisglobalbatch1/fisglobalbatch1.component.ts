import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fisglobalbatch1',
  templateUrl: './fisglobalbatch1.component.html',
  styleUrls: ['./fisglobalbatch1.component.css']
})
export class Fisglobalbatch1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
