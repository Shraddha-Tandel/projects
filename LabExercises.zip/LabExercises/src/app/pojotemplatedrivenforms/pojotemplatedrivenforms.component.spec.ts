import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PojotemplatedrivenformsComponent } from './pojotemplatedrivenforms.component';

describe('PojotemplatedrivenformsComponent', () => {
  let component: PojotemplatedrivenformsComponent;
  let fixture: ComponentFixture<PojotemplatedrivenformsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PojotemplatedrivenformsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PojotemplatedrivenformsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
