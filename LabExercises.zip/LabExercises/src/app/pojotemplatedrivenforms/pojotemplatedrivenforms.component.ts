import { Component, OnInit } from '@angular/core';
import { User123 } from '../TypeScriptClasses/User';

@Component({
  selector: 'app-pojotemplatedrivenforms',
  templateUrl: './pojotemplatedrivenforms.component.html',
  styleUrls: ['./pojotemplatedrivenforms.component.css']
})
export class PojotemplatedrivenformsComponent implements OnInit {
  uobj1 = new User123();

  constructor() { }

  ngOnInit(): void {
  }
  FISUserSubmit(ff:any)//ff(formname) not used!! POJO OBJECT IS ENOUGH!!!
  {
  console.log("User Details:"+this.uobj1.name+ " "+this.uobj1.userid+ " "+this.uobj1.email+ " "+this.uobj1.age);
  }


}
