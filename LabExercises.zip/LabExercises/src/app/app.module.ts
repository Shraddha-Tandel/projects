import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FisglobalbatchComponent } from './fisglobalbatch/fisglobalbatch.component';
import { Fisglobalbatch1Component } from './fisglobalbatch1/fisglobalbatch1.component';
import { MybatchComponent } from './fisglobalbatch123/mybatch/mybatch.component';
import { FisPuneDirective } from './mydirectives/fispune.directive';
import { TaxcalcPipe } from './mypipes/taxcalc.pipe';
import { AgecalcPipe } from './mypipes/agecalc.pipe';
import { IdentityPipe } from './mypipes/identity.pipe';
import { NocssnohtmlonlytsComponent } from './nocssnohtmlonlyts/nocssnohtmlonlyts.component';
import { PojotemplatedrivenformsComponent } from './pojotemplatedrivenforms/pojotemplatedrivenforms.component';
import { ReactiveformsComponent } from './reactiveforms/reactiveforms.component';
import { Childcom1Component } from './childcom1/childcom1.component';
import { Childcom2Component } from './childcom2/childcom2.component';
import { Childcom3Component } from './childcom3/childcom3.component';
import { TemperatureConverterComponent } from './temperature-converter/temperature-converter.component';
import { StringReverserComponent } from './string-reverser/string-reverser.component';
import { UserFormComponent } from './user-form/user-form.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { SenderComponent } from './sender/sender.component';
import { ReceiverComponent } from './receiver/receiver.component';

@NgModule({
  declarations: [
    AppComponent,
    FisglobalbatchComponent,
    Fisglobalbatch1Component,
    MybatchComponent,
    FisPuneDirective,
    TaxcalcPipe,
    AgecalcPipe,
    IdentityPipe,
    NocssnohtmlonlytsComponent,
    PojotemplatedrivenformsComponent,
    ReactiveformsComponent,
    Childcom1Component,
    Childcom2Component,
    Childcom3Component,
    TemperatureConverterComponent,
    StringReverserComponent,
    UserFormComponent,
    ParentComponent,
    ChildComponent,
    SenderComponent,
    ReceiverComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule, ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
