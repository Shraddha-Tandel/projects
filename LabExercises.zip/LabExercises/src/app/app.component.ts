import { Component, ViewChild } from '@angular/core';
import { PurchaseDetails } from './TypeScriptClasses/Purchase';
import { Employee1 } from './TypeScriptClasses/Employee';
import { UserdetailsService } from './myservices/userdetails.service';
import { Childcom1Component } from './childcom1/childcom1.component';
export class FormData {
  name: string = '';
  address: string = '';
  date: string = '';
  orderNumber: string = '';
}
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Angular Framework 14';
  trainingloc = 'Chennai';
  name = 'Karpagavalli';

  names: string[] = ['Devi', 'Abi', 'Rajan', 'Thananya'];
  salary: number[] = [80000.0, 70500.0, 56993.7, 46574.7];
  dept1 = new Array('HR', 'Sales', 'Purchase', 'Operations');

  formData: FormData = new FormData();
  onSubmitform2(form: any): void {
    if (form.valid) {
      console.log('Form Data:', this.formData);
    } else {
      console.log('Form is invalid');
    }
  }
  disp1() {
    alert('HEY !');
  }
  today123 = new Date();
  pobj: PurchaseDetails = {
    purchaseid: 1001,
    itemname: 'Dell Laptop',
    vendoremail: 'dell@gmail.com',
    quantity: 22,
    purchase_date: this.today123,
  };

  dateStrobj = new Date();

  trainees = [
    {
      id: 1001,
      name: 'Swara',
      loc: 'Pune',
      dob: this.dateStrobj.toLocaleDateString(),
    },
    {
      id: 1002,
      name: 'Zanwar',
      loc: 'Hyderbad',
      dob: new Date('5/30/2005'),
    },
    {
      id: 1003,
      name: 'Isha',
      loc: 'Pimpri',
      dob: new Date('9/15/2002'),
    },
  ];
  //nested json
  data1 = [
    {
      name: 'Tanmay',
      cars: [{ car: 'Ford' }, { car: 'BMW' }],
    },
    {
      name: 'Rishab',
      cars: [{ car: 'Honda' }, { car: 'Fiat' }],
    },
  ];

  public obj1234: Employee1 = new Employee1();

  public obj123: Employee1 = new Employee1(1, 'Rishab', 43454);
  public obj12: Employee1 = new Employee1(1001, 'Tanmay');
  public obj13: Employee1 = new Employee1(1002, 363569);

  signIn: boolean = true;
  obj113 = new Employee1(1001, 'Thananya', 96454);
  obj14: Employee1 | undefined; //null
  isMobile: boolean = false;
  Name: any = 'Apple iPhone 13';
  Description: any =
    'Super Retina XDR display ,15.4 cm / 6.1″ (diagonal) all‑screen OLED display';

  //switch case
  color1: any = 'red'; //color1=red
  //any is a datatype!

  //json variable
  people = [
    {
      name: 'Abi',
      age: 23,
      country: 'INDIA',
    },
    {
      name: 'Thananya',
      age: 5,
      country: 'USA',
    },
    {
      name: 'Devi',
      age: 34,
      country: 'INDIA',
    },
    {
      name: 'Kanishka',
      age: 31,
      country: 'UK',
    },
  ];

  //style binding function
  getColor1() {
    return 'green';
  }

  //ngstyle
  isBold: boolean = true;
  fontSize: number = 30;
  isItalic: boolean = true;
  MyStyle() {
    //typescript method
    let mystyles = {
      //original css property
      'font-weight': this.isBold ? 'bold' : 'normal',
      'font-style': this.isItalic ? 'italic' : 'normal',
      'font-size.px': this.fontSize,
    };
    return mystyles;
  }

  //arrays
  prglang = ['Java', 'C', 'C++'];

  //PIPES
  myname = 'Karpagavalli';
  todaydate = new Date();
  todaydate1 = new Date(2021, 10, 20);
  monthsobj = [
    'Jan',
    'Feb',
    'Mar',
    'April',
    'May',
    'Jun',
    'July',
    'Aug',
    'Sept',
    'Oct',
    'Nov',
    'Dec',
  ];

  employees: any[] = [
    {
      code: '101',
      name: 'Jay',
      gender: 'Male',
      annualSalary: 550000,
      dateOfBirth: '6/26/1988',
    },
    {
      code: '102',
      name: 'Adam',
      gender: 'Male',
      annualSalary: 122700.95,
      dateOfBirth: '9/6/1982',
    },
    {
      code: '103',
      name: 'Surya',
      gender: 'Male',
      annualSalary: 590000,
      dateOfBirth: '8/28/1979',
    },
    {
      code: '104',
      name: 'Thananya',
      gender: 'Female',
      annualSalary: 6500997,
      dateOfBirth: '12/20/1980',
    },
  ];

  data: any;
  h1: any = [];
  currentdate1: any;
  constructor(private dataserviceobj: UserdetailsService) {
    this.h1 = this.dataserviceobj.Hobbies;
    this.data = this.dataserviceobj.Display3();
    this.currentdate1 = this.dataserviceobj.getTime12().toLocaleDateString();
  }

  onSubmitform1(form: any): void {
    if (form.valid) {
      console.log('Form Data:', form.value);
    } else {
      console.log('Form is invalid');
    }
  }

  students: any[] | undefined;
  ngOnInit() {
    this.students = this.dataserviceobj.getStudents();
  }

  communicationmode: any[] = ['Phone', 'Email', 'Landline'];

  eno_1: any;
  ename_1: any;
  fisformSubmit(a1: any) {
    this.eno_1 = a1.EmpNo;
    this.ename_1 = a1.EmpName;
    console.log(
      'Emp Details: ' +
        a1.EmpNo +
        ' ' +
        a1.EmpName +
        ' ' +
        a1.Gen1 +
        ' ' +
        a1.languages +
        ' ' +
        a1.cm1
    );
    window.alert(
      a1.EmpNo +
        ' ' +
        a1.EmpName +
        ' ' +
        a1.Gen1 +
        ' ' +
        a1.languages +
        ' ' +
        a1.cm1
    );
  }

  @ViewChild(Childcom1Component)
  private childobj: Childcom1Component | any; //object
  var1: any;

  ngAfterViewInit() {
    console.log('ngAfterViewInit() Loaded');
    this.var1 = this.childobj.childmsg11;
  }

  @ViewChild('content1') mainContent: any;
  @ViewChild('content2') subContent: any;
  public change1() {
    console.log('changeMainContent');
    this.mainContent.nativeElement.setAttribute('style', 'color:red');
  }

  public change2() {
    console.log('changeSubContent');
    this.subContent.nativeElement.setAttribute('style', 'color:darkgreen');
  }

  public products: any = [
    { name: 'Pepsi', price: 100 },
    { name: 'Fanta', price: 120 },
    { name: 'Mirinda', price: 190 },
    { name: 'Bovonto', price: 160 },
  ];

  //Event emitting
  childdata: any;
  FISParentMethod(data: any) {
    this.childdata = data;
  }
}
