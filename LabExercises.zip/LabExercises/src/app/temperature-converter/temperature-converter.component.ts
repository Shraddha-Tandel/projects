import { Component } from '@angular/core';

@Component({
  selector: 'app-temperature-converter',
  templateUrl: './temperature-converter.component.html',
  styleUrls: ['./temperature-converter.component.css']
})
export class TemperatureConverterComponent {
  // Variables for Celsius to Fahrenheit conversion
  celsiusInput: number | null = null;
  fahrenheitOutput: number | null = null;

  // Variables for Fahrenheit to Celsius conversion
  fahrenheitInput: number | null = null;
  celsiusOutput: number | null = null;

  // Convert Fahrenheit to Celsius
  convertFahrenheitToCelsius(): void {
    if (this.fahrenheitInput !== null) {
      this.celsiusOutput = (this.fahrenheitInput - 32) * 5 / 9;
    }
  }

  // Convert Celsius to Fahrenheit
  convertCelsiusToFahrenheit(): void {
    if (this.celsiusInput !== null) {
      this.fahrenheitOutput = (this.celsiusInput * 9 / 5) + 32;
    }
  }
}
