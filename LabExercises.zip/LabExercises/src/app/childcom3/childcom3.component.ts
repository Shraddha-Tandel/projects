import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-childcom3',
  templateUrl: './childcom3.component.html',
  styleUrls: ['./childcom3.component.css']
})
export class Childcom3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  
//@Input() lets a parent component update data in the child component. 
//Conversely, @Output() lets the child send data to a parent component.

//CHILD TO PARENT COMMUNICATION

 /*to emit an event from the child component class
  to the parent component class, 
  use EventEmitter with the @Output() decorator.
 
  Use EventEmitter only for event binding between a 
 child and parent component.
 */
//@Output & @EventEmitter to notify your 
 //parent component through child component.
 @Output()
 notify12:EventEmitter<any>=new EventEmitter<any>();//notify12 is object
 
 passdata()
 {
 this.notify12.emit("Hi Parent!!This message is coming from child component")
 }

}
