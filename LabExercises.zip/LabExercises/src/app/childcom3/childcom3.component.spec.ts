import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Childcom3Component } from './childcom3.component';

describe('Childcom3Component', () => {
  let component: Childcom3Component;
  let fixture: ComponentFixture<Childcom3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Childcom3Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Childcom3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
