//typescript class
export class User123
{
userid:number | undefined;
name:string | undefined;
email:string | undefined;
age:number | undefined;
}