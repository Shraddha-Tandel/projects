export class Employee1
{
    eno:number | undefined;
    name:string | undefined ;
    salary:number | undefined;

//default constructor
/*constructor()
{
this.eno=1001;
this.name="Kanishka";
this.salary=54999;
console.log("Employee Default Constructor Loaded::"+this.eno + " "+this.name+ " "+this.salary);
}*/
//By default multiple constructor implementation are not allowed!
//? symbol declare a parameter is optional.
//any refers ==any data types
//The any type is a special type in TypeScript that allows variables to hold values of any type
//The any data type is the super type of all types in TypeScript. It denotes a dynamic type. 

constructor(a?:any,b?:any,c?:number)//NOT A TERNARY OPERATOR!
{
    this.eno=a;
    this.name=b;
    this.salary=c;
    console.log("Emp Para Constructor Loaded");
}
}