/*
In Angular, creating a custom validator is as simple as creating another function. The only thing you need to
keep in mind is that it takes one input parameter of type ""AbstractControl""" and it returns an object
of a key-value pair if the validation fails.

The type of the first parameter is AbstractControl, because it is a base class of FormControl, FormArray, and
 FormGroup,
and it allows you to read the value of the control passed to the custom validator function. The custom validator
returns either of the following:

1.If the validation fails, it returns an object, which
contains a key-value pair. Key is the name of the error
and the value is always Booleantrue.

2.If the validation does not fail, it returns null.
function ageRangeValidator(control: AbstractControl):
{ [key: string]: boolean } | null
{
}
*/

import { AbstractControl, ValidationErrors } from "@angular/forms";

export class FISValidation
{
    //typescript validation method
    //isNaN() method returns true if a value is Not-a-Number.

    static FIS_ageRangeValidator(controlobj: AbstractControl):ValidationErrors | null
    {
 if (controlobj.value !== undefined && (isNaN(controlobj.value)|| controlobj.value < 18 || controlobj.value > 45))
        {
        return { 'FIS_ageRangeValidator': true };//fails
        }
        return null;//not fails
    
    }
}