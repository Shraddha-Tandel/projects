//typescript class
/*
Undefined is a type of Data type in JavaScript. When a variable is declared and 
not initialized or not assigned with any value.*/

export class PurchaseDetails
{
    
    // a:number;//invalid
    purchaseid:number | undefined;
    
itemname:string | undefined;
vendoremail:string | undefined;
quantity:number | undefined;
purchase_date:Date | undefined;

}