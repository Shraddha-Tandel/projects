import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private apiUrl = 'https://localhost:44345/api/UserRegistrationApi';  // Your ASP.NET API URL

  constructor(private http: HttpClient) { }

  // Fetch users
  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.apiUrl}/ListUsers`);
  }

  // Add a new user
  addUser(newUser: User): Observable<User> {
    return this.http.post<User>(`${this.apiUrl}/AddUser`, newUser);
  }

  // Update a user
  updateUser(updatedUser: User): Observable<any> {
    return this.http.put(`${this.apiUrl}/UpdateUser`, updatedUser);
  }

  // Delete a user
  deleteUser(userId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/DeleteUser/${userId}`);
  }
}
