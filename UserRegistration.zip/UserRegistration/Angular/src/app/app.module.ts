import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserManagementComponent } from './components/user-management/user-management.component';
import { UserService } from './services/user.service';

@NgModule({
  declarations: [
    AppComponent,
    UserManagementComponent  // Declare the UserManagementComponent here
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule  // Needed for form handling
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
